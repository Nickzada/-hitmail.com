const f = require('./functions.js')

class Auth {

    async Auth(cc, mes, ano, cvv) {
      let login = await f.curl({
            url: `http://localhost:443/amazon?data=${cc}|${mes}|${ano}|${cvv}`,
            method: 'GET',
            rejectUnauthorized: false,
        })
        let retorno = JSON.parse(login.response);

        if(String(retorno.status) == 0) {
            return {c : 0,  msg: retorno.msg}
        }else{
          return { c: 1, response: retorno.msg}
        }
    }
}

module.exports = new Auth
