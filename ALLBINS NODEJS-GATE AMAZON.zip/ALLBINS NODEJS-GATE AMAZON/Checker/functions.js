const request = require('request')
const fs = require('fs')
const jar = request.jar()

const self = {
    curl: opt => {
        return new Promise((resolve, reject) => {
            // opt['jar'] = jar
            request(opt, (err, req, res) => {
                if(err) {
                    reject(err)
                }else{
                    resolve({"response": res, "header": req.headers})
                }
            })
        })
    },
    extract: (string, left, right) => {
        try {
            let r1 = string.split(left)
            let r = r1[1].split(right)
            return r[0]
        } catch (err) {
            console.log(`Funcao Eparse: ${err}`)
            return null
        }
    },
    open: file => {
        return fs.readFileSync(file, {encoding: 'utf-8'}).toString().split('\n')
    },
    save: (txt, line) => {
        fs.appendFileSync(`out/Lives.txt`, `${line}\n`, 'utf8')
    },
    save_err: (text, line) => {
        fs.appendFileSync('out/tocheck.txt', `BODY: \n${text}\n\nLOGIN: ${line}\n`)
    },
    sleep: ms => {
        return new Promise(resolve => setTimeout(resolve, ms))
    },
    explode: line => {
        return line.replace(/[|/;\\» ]/gmsi, ':').split(':').filter((v) => (v.trim()));
    },
    isFile: file => {
        return fs.existsSync(file)
    },
    Find: (str, word) => {
        if(!str) return false;
        let found = false
        word.forEach(l => { 
            if(str.match(l)) {
                if(!found) found = true
            }
        });
        return found
    }
}

module.exports = self;