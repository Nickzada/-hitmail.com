const cli = require('cli-color');
const f = require('./functions.js');
const Auth = require('./requests')
class App {

    constructor(file) {
        this.bots = 10
        this.file = file;
        this.lista = [];
        this.tested = 0;
        this.lista.length = 0;
        this.live = 0;
        this.die = 0;
        this.retry = 0;
        this.error = 0;
        this.Prepare()
    }

    Title() {
        process.title = `Checker AllBins -X [2023 ] -X | ${this.tested}/${this.lista.length} | Lives: ${this.live} | Dies: ${this.die} | Reteste: ${this.retry} | Erro: ${this.error}`;
    }

    Load() {
        try {
            this.lista = f.open(this.file);
        } catch (err) {
            let error = `Erro na Lista: ${err.path}`
            throw error
        }
    }

    Prepare() {
        this.Load()
        let workers = []
        for (let i = 0; i < this.bots; i++) {
            workers.push(i)
        }
        workers.filter(() => {
            this.Machine()
        })
    }

    async Machine() {
        while(true) {
            if(!this.lista[0]) break
            let line = this.lista[0]
            this.lista.splice(0, 1)
            await this.Check(line)
        }
    }

    async Check(line) {
        const [cc, mes, ano, cvv] = line.trim().split('|');

        try {

            let login = await Auth.Auth(cc, mes, ano, cvv)
            if(login.c == 1) {
                this.die++
                this.tested++
                console.log(cli.redBright(`Die - ${cc}|${mes}|${ano}|${cvv} | Retorno: Cartão Recusado`));
                //console.log(login.response)
            }else if(login.c == 0){
                    this.live++
                    this.tested++
                    f.save(`Live ++`, line)
                    console.log(cli.greenBright(`Live - ${login.msg}.`));
                }else{
                    this.die++
                    this.tested++
                    console.log(cli.redBright(`Die - ${cc}|${mes}|${ano}|${cvv} | Retorno: Erro Interno.`));
                }

        } catch (err) {
            this.retry++
            if(!this.lista.includes(line)) this.lista.push(line)
        }
        this.Title()
    }
}


const file_db = 'db/lista.txt';

if(!f.isFile(file_db)) return console.log(cli.red(`${file_db} Arquivo Não Encontrado.`));
if(f.open(file_db)[0].length == 0) return console.log(cli.red(`${file_db} Lista Vazia.`));

new App(file_db)
