require('dotenv').config();
const express = require('express')
const app = express()
const http = require('http').createServer(app)
const Amazon = require('./modules/amazon')
const Cielo = require('./modules/cielo')
const delay = require('delay')
const fs = require('fs')


app.get('/amazon', async (req, res) => {
	//await delay(1000);
  const value = req.query.data;
  const [cc, mes, ano, cvv] = value.trim().split('|');
  const b = await Amazon.invoke({ cc, mes, ano, cvv });
	  console.log(b);
    res.json(b);
    if (!b.status) {
      fs.appendFileSync("Lives.txt", `${b.msg}\n`);
      return console.log(b.msg);
    } else {
        fs.appendFileSync("Dies.txt", `${b.msg}\n`);
        return console.log(b.msg);
    }
});

app.get('/cielo', async (req, res) => {
	//await delay(1000);
  const value = req.query.data;
  const [cc, mes, ano, cvv] = value.trim().split('|');
  const b = await Cielo.invoke({ cc, mes, ano, cvv });
	  console.log(b);
    res.json(b);
    if (!b.status) {
      fs.appendFileSync("LivesCielo.txt", `${b.msg}\n`);
      return console.log(b.msg);
    } else {
        fs.appendFileSync("DiesCielo.txt", `${b.msg}\n`);
        return console.log(b.msg);
    }
});

app.get('/teste', async (req, res) => {
    res.json({doc: '1234'});
});


const port = 443
http.listen(port, () => {
	console.log(`Server Rodando na Porta: ${port}`)
})
